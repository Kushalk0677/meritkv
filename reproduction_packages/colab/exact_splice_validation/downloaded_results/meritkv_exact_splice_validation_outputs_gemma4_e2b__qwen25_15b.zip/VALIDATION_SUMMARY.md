# Gemma-4-E2B and Qwen2.5-1.5B Exact-Splice Validation Summary

- Reports: 3
- All strict pass: `False`
- All token pass: `True`

| Report | Attention | Cases | Strict | Cache | Native tokens | Splice tokens |
|---|---|---:|---:|---:|---:|---:|
| `gemma4_e2b_t4_f16_sdpa.json` | sdpa | 8 | 0 | 0 | 8 | 8 |
| `qwen25_15b_t4_f16_eager.json` | eager | 8 | 0 | 0 | 8 | 8 |
| `qwen25_15b_t4_f16_sdpa.json` | sdpa | 8 | 0 | 4 | 8 | 8 |

## Maximum Absolute Differences

### `gemma4_e2b_t4_f16_sdpa.json`

- prefix_cache: `0.55859375`
- suffix_native_vs_full: `0.279296875`
- suffix_splice_vs_full: `0.328125`
- suffix_splice_vs_native: `0.2802734375`
- generation_native_vs_full: `0.224609375`
- generation_splice_vs_full: `0.2265625`
- generation_splice_vs_native: `0.2734375`

### `qwen25_15b_t4_f16_eager.json`

- prefix_cache: `0.125`
- suffix_native_vs_full: `nan`
- suffix_splice_vs_full: `nan`
- suffix_splice_vs_native: `nan`
- generation_native_vs_full: `nan`
- generation_splice_vs_full: `nan`
- generation_splice_vs_native: `nan`

### `qwen25_15b_t4_f16_sdpa.json`

- prefix_cache: `0.125`
- suffix_native_vs_full: `0.109375`
- suffix_splice_vs_full: `0.109375`
- suffix_splice_vs_native: `0.060546875`
- generation_native_vs_full: `0.35546875`
- generation_splice_vs_full: `0.353515625`
- generation_splice_vs_native: `0.028228759765625`

