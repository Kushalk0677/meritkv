# Qwen2.5 Corrected-Splice Rescue Check

Paired T4 comparison of the manuscript's original mask/position-implicit custom splice and the corrected SDPA path with a complete attention mask, explicit logical `position_ids`, and `cache_position`.

## Aggregate

| Metric | Original diagnostic | Frozen paper backend | Fully explicit corrected |
|---|---:|---:|---:|
| Exact decoded-output matches | 64/78 | 64/78 | 64/78 |
| Mean ROUGE-L | 0.9622 | 0.9622 | 0.9622 |
| Mean cached-prefill speedup vs full prefill | 1.0587x | 1.0448x | 1.0385x |
| Mean cached-prefill latency | 41.5105 ms | 42.0799 ms | 42.4101 ms |

Corrected/original cached-prefill latency ratio: `1.021673`.
Corrected/frozen-paper-backend latency ratio: `1.007849`.

## Per dataset

| Dataset | N | Original ROUGE-L | Paper-backend ROUGE-L | Corrected ROUGE-L | Paper-backend speedup | Corrected speedup |
|---|---:|---:|---:|---:|---:|---:|
| samsum | 8 | 0.9989 | 0.9989 | 0.9989 | 1.0333x | 1.0360x |
| xsum | 8 | 0.9574 | 0.9574 | 0.9574 | 1.0452x | 1.0435x |
| cnn_dailymail | 8 | 0.9545 | 0.9545 | 0.9545 | 0.9895x | 0.9822x |
| ag_news | 8 | 0.9319 | 0.9319 | 0.9319 | 1.0461x | 1.0483x |
| banking77 | 8 | 0.9973 | 0.9973 | 0.9973 | 1.0711x | 1.0462x |
| alpaca_eval | 8 | 0.9281 | 0.9281 | 0.9281 | 1.0676x | 1.0880x |
| dolly | 7 | 0.9844 | 0.9844 | 0.9844 | 1.0610x | 1.0808x |
| daily_dialog | 8 | 1.0000 | 1.0000 | 1.0000 | 1.0536x | 1.0137x |
| oasst1 | 7 | 0.8888 | 0.8888 | 0.8888 | 1.0843x | 1.0720x |
| ultrachat | 8 | 0.9737 | 0.9737 | 0.9737 | 1.0038x | 0.9839x |

Speedup is full-prefill latency divided by cached-suffix-prefill latency on the same prompt. Source-cache creation is excluded because the cache is assumed to pre-exist; cache isolation and cropping are included. Absolute T4 ratios are not substituted for the paper's Blackwell values. The paired old/new difference tests whether the correctness fix changes the reuse economics.
