from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from proactive_kv_cache.datasets import list_datasets, list_prompt_modes
from proactive_kv_cache.controller import AdaptiveReuseController, ReusePlan
from proactive_kv_cache.metrics import summarize_run
from proactive_kv_cache.utils import set_seed
from proactive_kv_cache.workload import SYNTHETIC_VARIANTS, Request, make_public_dataset_workload, make_synthetic_workload


MODEL_PRESETS = {
    "tiny": "sshleifer/tiny-gpt2",
    "distilgpt2": "distilgpt2",
    "gpt2": "gpt2",
    "phi3mini": "microsoft/Phi-3-mini-4k-instruct",
    "llama32_1b": "meta-llama/Llama-3.2-1B-Instruct",
    "qwen25_15b": "Qwen/Qwen2.5-1.5B-Instruct",
    "qwen25_3b": "Qwen/Qwen2.5-3B-Instruct",
    "mistral7b": "mistralai/Mistral-7B-Instruct-v0.3",
    "llama31_8b": "meta-llama/Llama-3.1-8B-Instruct",
}


def resolve_model(model: str | None) -> str | None:
    if model is None:
        return None
    return MODEL_PRESETS.get(model, model)


def resolve_prompt_mode(args: argparse.Namespace) -> str:
    if args.prompt_mode != "auto":
        return args.prompt_mode
    if args.workload == "public_dataset":
        return "templated"
    return "raw"


def maybe_sleep(current_idx: int, requests: Sequence[Request], simulate_arrivals: bool, max_sleep_ms: float) -> None:
    if not simulate_arrivals or current_idx == 0:
        return
    delay = requests[current_idx].arrival_time - requests[current_idx - 1].arrival_time
    if delay > 0:
        time.sleep(min(delay, max_sleep_ms / 1000.0))


def build_requests(args: argparse.Namespace) -> List[Request]:
    prompt_mode = getattr(args, "resolved_prompt_mode", "raw")
    if args.workload == "synthetic":
        return make_synthetic_workload(
            variant=args.variant,
            n_requests=args.n_requests,
            seed=args.seed,
            mean_inter_arrival_ms=args.mean_inter_arrival_ms,
        )
    if args.workload == "public_dataset":
        return make_public_dataset_workload(
            dataset_name=args.dataset,
            split=args.dataset_split,
            n_requests=args.n_requests,
            seed=args.seed,
            mean_inter_arrival_ms=args.mean_inter_arrival_ms or 150.0,
            prompt_mode=prompt_mode,
        )
    raise ValueError(f"Unsupported workload: {args.workload}")


def add_workload_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model", required=True)
    parser.add_argument("--workload", choices=["synthetic", "public_dataset"], default="public_dataset")
    parser.add_argument("--variant", choices=sorted(SYNTHETIC_VARIANTS.keys()), default="high_skew")
    parser.add_argument("--dataset", choices=list_datasets(), default="daily_dialog")
    parser.add_argument("--prompt_mode", choices=["auto", *list_prompt_modes()], default="auto")
    parser.add_argument("--dataset_split", default=None)
    parser.add_argument("--n_requests", type=int, default=64)
    parser.add_argument("--simulate_arrivals", dest="simulate_arrivals", action="store_true")
    parser.add_argument("--disable_arrival_simulation", dest="simulate_arrivals", action="store_false")
    parser.set_defaults(simulate_arrivals=True)
    parser.add_argument("--mean_inter_arrival_ms", type=float, default=50.0)
    parser.add_argument("--max_arrival_sleep_ms", type=float, default=500.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_dir", default="results_external")
    parser.add_argument("--max_tokens", type=int, default=1)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--request_timeout_s", type=float, default=600.0)


def normalize_api_base(api_base: str | None, host: str, port: int) -> str:
    if api_base:
        return api_base.rstrip("/")
    return f"http://{host}:{port}"


def model_slug(model: str | None) -> str:
    return (resolve_model(model) or model or "default").replace("/", "_").replace(":", "_").replace(".", "_")


def workload_slug(args: argparse.Namespace) -> str:
    if args.workload == "public_dataset":
        return f"{args.dataset}_{args.resolved_prompt_mode}"
    return args.variant


def save_summary(output_dir: str, filename: str, payload: Dict[str, Any]) -> Path:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / filename
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path


def make_output_filename(prefix: str, args: argparse.Namespace) -> str:
    return f"{prefix}_{model_slug(args.model)}_{args.workload}_{workload_slug(args)}.json"


@dataclass
class ExternalCallResult:
    request_id: int
    latency_ms: float
    end_to_end_latency_ms: float | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0


def _percentile(values: Sequence[float], percentile: float) -> float:
    clean = sorted(float(value) for value in values)
    if not clean:
        return 0.0
    if len(clean) == 1:
        return clean[0]
    rank = (len(clean) - 1) * (float(percentile) / 100.0)
    low = int(rank)
    high = min(low + 1, len(clean) - 1)
    weight = rank - low
    return clean[low] * (1.0 - weight) + clean[high] * weight


def summarize_external_results(
    results: Sequence[ExternalCallResult],
    *,
    total_wall_time_s: float | None = None,
    extra_metrics: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    http_latencies = [result.latency_ms for result in results]
    end_to_end_latencies = [
        result.end_to_end_latency_ms if result.end_to_end_latency_ms is not None else result.latency_ms
        for result in results
    ]
    http_latency_sum_s = sum(http_latencies) / 1000.0
    end_to_end_latency_sum_s = sum(end_to_end_latencies) / 1000.0
    measured_wall_time_s = (
        max(float(total_wall_time_s), 1e-9)
        if total_wall_time_s is not None
        else max(end_to_end_latency_sum_s, 1e-9)
    )
    merged_extra = {
        "requests_seen": len(results),
        "reuse_attempts": 0,
        "reuse_successes": 0,
        "reuse_failures": 0,
        "reuse_backend_fallbacks": 0,
        "store_attempts": 0,
        "store_successes": 0,
        "store_skips": 0,
        "bypassed_matches": 0,
        "reused_prefix_tokens_total": 0,
        "recompute_tokens_total": 0,
        "estimated_tokens_saved_total": 0,
        "saved_latency_estimate_ms": 0.0,
        "store_latency_total_ms": 0.0,
        "full_prefill_latency_total_ms": 0.0,
        "measured_wall_time_s": measured_wall_time_s,
        "http_latency_sum_s": http_latency_sum_s,
        "http_latency_mean_ms": float(http_latency_sum_s * 1000.0 / max(len(results), 1)),
        "http_latency_p50_ms": _percentile(http_latencies, 50),
        "http_latency_p95_ms": _percentile(http_latencies, 95),
        "http_latency_p99_ms": _percentile(http_latencies, 99),
        "end_to_end_latency_sum_s": end_to_end_latency_sum_s,
        "end_to_end_latency_mean_ms": float(end_to_end_latency_sum_s * 1000.0 / max(len(results), 1)),
        "end_to_end_latency_p50_ms": _percentile(end_to_end_latencies, 50),
        "end_to_end_latency_p95_ms": _percentile(end_to_end_latencies, 95),
        "end_to_end_latency_p99_ms": _percentile(end_to_end_latencies, 99),
    }
    merged_extra.update(extra_metrics or {})
    summary = summarize_run(
        latencies=end_to_end_latencies,
        gpu_utils=[None] * len(results),
        bank_metrics={},
        speculative_precomputes=0,
        speculative_cost_ms=0.0,
        total_wall_time_s=measured_wall_time_s,
        extra_metrics=merged_extra,
    ).to_dict()
    summary.update(merged_extra)
    summary["measured_wall_time_s"] = measured_wall_time_s
    summary["http_latency_sum_s"] = http_latency_sum_s
    summary["http_latency_mean_ms"] = merged_extra["http_latency_mean_ms"]
    summary["http_latency_p50_ms"] = merged_extra["http_latency_p50_ms"]
    summary["http_latency_p95_ms"] = merged_extra["http_latency_p95_ms"]
    summary["http_latency_p99_ms"] = merged_extra["http_latency_p99_ms"]
    summary["end_to_end_latency_sum_s"] = end_to_end_latency_sum_s
    summary["end_to_end_latency_mean_ms"] = summary["mean_latency_ms"]
    summary["end_to_end_latency_p50_ms"] = summary["p50_latency_ms"]
    summary["end_to_end_latency_p95_ms"] = summary["p95_latency_ms"]
    summary["end_to_end_latency_p99_ms"] = summary["p99_latency_ms"]
    summary["end_to_end_throughput_rps"] = summary["throughput_rps"]
    summary["http_service_throughput_rps"] = float(len(results) / max(http_latency_sum_s, 1e-9))
    summary["prompt_tokens_total"] = int(sum(result.prompt_tokens for result in results))
    summary["completion_tokens_total"] = int(sum(result.completion_tokens for result in results))
    summary["total_tokens_total"] = int(sum(result.total_tokens for result in results))
    summary["cached_tokens_total"] = int(sum(result.cached_tokens for result in results))
    summary["cached_tokens_mean"] = float(summary["cached_tokens_total"] / max(len(results), 1))
    return summary


class OpenAICompatClient:
    def __init__(self, api_base: str, model: str, endpoint: str = "chat") -> None:
        self.api_base = api_base.rstrip("/")
        self.model = model
        self.endpoint = endpoint

    def wait_until_ready(self, timeout_s: float = 180.0, poll_s: float = 1.0) -> None:
        deadline = time.time() + timeout_s
        last_error: str | None = None
        while time.time() < deadline:
            for path in ("/v1/models", "/health"):
                try:
                    req = urllib.request.Request(self.api_base + path, method="GET")
                    with urllib.request.urlopen(req, timeout=5.0) as resp:
                        if 200 <= resp.status < 300:
                            return
                except Exception as exc:  # pragma: no cover - runtime path
                    last_error = str(exc)
            time.sleep(poll_s)
        raise RuntimeError(f"Server at {self.api_base} did not become ready within {timeout_s:.0f}s. Last error: {last_error}")

    def _post_json(self, path: str, body: Dict[str, Any], timeout_s: float) -> Dict[str, Any]:
        payload = json.dumps(body).encode("utf-8")
        request = urllib.request.Request(
            self.api_base + path,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout_s) as response:
            raw = response.read().decode("utf-8")
        return json.loads(raw)

    def post_empty(self, path: str, timeout_s: float = 30.0) -> int:
        request = urllib.request.Request(
            self.api_base + path,
            data=b"",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout_s) as response:
            response.read()
            return int(response.status)

    def get_text(self, path: str, timeout_s: float = 30.0) -> str:
        request = urllib.request.Request(self.api_base + path, method="GET")
        with urllib.request.urlopen(request, timeout=timeout_s) as response:
            return response.read().decode("utf-8")

    def get_json(self, path: str, timeout_s: float = 30.0) -> Dict[str, Any]:
        raw = self.get_text(path, timeout_s=timeout_s)
        return json.loads(raw)

    def invoke(
        self,
        *,
        prompt: str | None = None,
        messages: Sequence[Dict[str, str]] | None = None,
        max_tokens: int = 1,
        temperature: float = 0.0,
        timeout_s: float = 600.0,
        extra_body: Dict[str, Any] | None = None,
    ) -> ExternalCallResult:
        body: Dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if extra_body:
            body.update(extra_body)
        if self.endpoint == "chat":
            body["messages"] = list(messages) if messages is not None else [{"role": "user", "content": prompt or ""}]
            path = "/v1/chat/completions"
        elif self.endpoint == "completion":
            if prompt is None and messages is not None:
                prompt = "\n".join(str(item.get("content", "")) for item in messages)
            body["prompt"] = prompt or ""
            path = "/v1/completions"
        else:
            raise ValueError(f"Unsupported endpoint: {self.endpoint}")

        start = time.perf_counter()
        payload = self._post_json(path, body, timeout_s=timeout_s)
        latency_ms = (time.perf_counter() - start) * 1000.0

        usage = payload.get("usage") or {}
        prompt_tokens = int(usage.get("prompt_tokens") or 0)
        completion_tokens = int(usage.get("completion_tokens") or 0)
        total_tokens = int(usage.get("total_tokens") or (prompt_tokens + completion_tokens))
        prompt_details = usage.get("prompt_tokens_details") or {}
        cached_tokens = int(prompt_details.get("cached_tokens") or 0)
        return ExternalCallResult(
            request_id=-1,
            latency_ms=float(latency_ms),
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            cached_tokens=cached_tokens,
        )


VLLM_CACHE_METRIC_NAMES = (
    "vllm:prefix_cache_queries_total",
    "vllm:prefix_cache_hits_total",
    "vllm:prompt_tokens_cached_total",
    "vllm:external_prefix_cache_queries_total",
    "vllm:external_prefix_cache_hits_total",
    "vllm:prompt_tokens_by_source_total",
)


def _prometheus_labels(label_text: str) -> Dict[str, str]:
    labels: Dict[str, str] = {}
    if not label_text:
        return labels
    current = []
    in_quotes = False
    escaped = False
    parts = []
    for char in label_text:
        if escaped:
            current.append(char)
            escaped = False
            continue
        if char == "\\":
            current.append(char)
            escaped = True
            continue
        if char == '"':
            current.append(char)
            in_quotes = not in_quotes
            continue
        if char == "," and not in_quotes:
            parts.append("".join(current))
            current = []
            continue
        current.append(char)
    if current:
        parts.append("".join(current))
    for part in parts:
        key, sep, value = part.partition("=")
        if not sep:
            continue
        labels[key.strip()] = value.strip().strip('"')
    return labels


def _metric_key(name: str, labels: Dict[str, str]) -> str:
    if name == "vllm:prompt_tokens_by_source_total":
        source = labels.get("source")
        if source:
            return f"{name}:{source}"
    return name


def parse_vllm_cache_metrics(metrics_text: str) -> Dict[str, float]:
    values: Dict[str, float] = {}
    for raw_line in metrics_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        sample, _, value_text = line.partition(" ")
        if not value_text:
            continue
        name = sample
        labels: Dict[str, str] = {}
        if "{" in sample and sample.endswith("}"):
            name, label_text = sample.split("{", 1)
            labels = _prometheus_labels(label_text[:-1])
        if name not in VLLM_CACHE_METRIC_NAMES:
            continue
        try:
            values[_metric_key(name, labels)] = float(value_text)
        except ValueError:
            continue
    return values


def collect_vllm_cache_metrics(client: OpenAICompatClient) -> Dict[str, Any]:
    try:
        values = parse_vllm_cache_metrics(client.get_text("/metrics", timeout_s=10.0))
        return {"available": True, "error": None, "values": values}
    except Exception as exc:
        return {"available": False, "error": str(exc), "values": {}}


def collect_shadowkv_admission_metrics(client: OpenAICompatClient) -> Dict[str, Any]:
    try:
        payload = client.get_json("/shadowkv_admission_metrics", timeout_s=10.0)
        counters = payload.get("counters", payload)
        return {"available": True, "error": None, "values": dict(counters or {})}
    except Exception as exc:
        return {"available": False, "error": str(exc), "values": {}}


def reset_shadowkv_admission_metrics(client: OpenAICompatClient) -> bool:
    try:
        client.post_empty("/shadowkv_admission_metrics/reset", timeout_s=10.0)
        return True
    except Exception:
        return False


def diff_counter_metrics(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
    before_values = dict(before.get("values") or {})
    after_values = dict(after.get("values") or {})
    keys = sorted(set(before_values) | set(after_values))
    deltas = {}
    for key in keys:
        try:
            deltas[key] = float(after_values.get(key, 0.0) - before_values.get(key, 0.0))
        except Exception:
            deltas[key] = after_values.get(key)
    return {
        "available": bool(before.get("available")) and bool(after.get("available")),
        "before": before,
        "after": after,
        "delta": deltas,
    }


def diff_vllm_cache_metrics(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
    before_values = dict(before.get("values") or {})
    after_values = dict(after.get("values") or {})
    keys = sorted(set(before_values) | set(after_values))
    deltas = {key: float(after_values.get(key, 0.0) - before_values.get(key, 0.0)) for key in keys}
    return {
        "available": bool(before.get("available")) and bool(after.get("available")),
        "before": before,
        "after": after,
        "delta": deltas,
        "prefix_cache_queries_delta": deltas.get("vllm:prefix_cache_queries_total", 0.0),
        "prefix_cache_hits_delta": deltas.get("vllm:prefix_cache_hits_total", 0.0),
        "prompt_tokens_cached_delta": deltas.get("vllm:prompt_tokens_cached_total", 0.0),
        "local_cache_hit_tokens_delta": deltas.get("vllm:prompt_tokens_by_source_total:local_cache_hit", 0.0),
        "external_prefix_cache_hits_delta": deltas.get("vllm:external_prefix_cache_hits_total", 0.0),
    }


class ManagedServer:
    def __init__(
        self,
        command: Sequence[str],
        *,
        cwd: str | None,
        env_updates: Dict[str, str] | None,
        stdout_path: Path,
        stderr_path: Path,
    ) -> None:
        self.command = list(command)
        self.cwd = cwd
        self.env_updates = dict(env_updates or {})
        self.stdout_path = stdout_path
        self.stderr_path = stderr_path
        self.process: subprocess.Popen[str] | None = None
        self._stdout_handle = None
        self._stderr_handle = None

    def start(self) -> None:
        env = os.environ.copy()
        env.update(self.env_updates)
        self.stdout_path.parent.mkdir(parents=True, exist_ok=True)
        self.stderr_path.parent.mkdir(parents=True, exist_ok=True)
        self._stdout_handle = self.stdout_path.open("w", encoding="utf-8")
        self._stderr_handle = self.stderr_path.open("w", encoding="utf-8")
        self.process = subprocess.Popen(
            self.command,
            cwd=self.cwd,
            env=env,
            stdout=self._stdout_handle,
            stderr=self._stderr_handle,
            text=True,
        )

    def poll(self) -> int | None:
        if self.process is None:
            return None
        return self.process.poll()

    def tail_logs(self, max_lines: int = 80) -> str:
        parts: List[str] = []
        for label, path in (("stdout", self.stdout_path), ("stderr", self.stderr_path)):
            try:
                if path.exists():
                    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
                    tail = "\n".join(lines[-max_lines:])
                    if tail.strip():
                        parts.append(f"--- {label}: {path} ---\n{tail}")
            except Exception as exc:  # pragma: no cover - diagnostic path
                parts.append(f"--- {label}: {path} ---\n<failed to read log: {exc}>")
        return "\n".join(parts)

    def stop(self) -> None:
        try:
            if self.process is not None and self.process.poll() is None:
                self.process.terminate()
                try:
                    self.process.wait(timeout=20.0)
                except subprocess.TimeoutExpired:  # pragma: no cover - runtime path
                    self.process.kill()
                    self.process.wait(timeout=5.0)
        finally:
            if self._stdout_handle is not None:
                self._stdout_handle.close()
            if self._stderr_handle is not None:
                self._stderr_handle.close()


def parse_command_string(command: str | None) -> List[str] | None:
    if not command:
        return None
    return shlex.split(command)


def vllm_compat_env_updates() -> Dict[str, str]:
    """Force vLLM's compatibility engine for portable baseline launches.

    Recent vLLM v1 builds can require optional flash-attn modules for some
    model families during initialization. The literature baselines value
    portability across Colab/T4/P100-style environments more than exercising
    the newest vLLM engine path, so launched vLLM servers use v0.
    """
    return {"VLLM_USE_V1": "0"}


def build_sglang_hicache_command(args: argparse.Namespace) -> List[str]:
    cmd = [
        args.python_executable,
        "-m",
        "sglang.launch_server",
        "--model-path",
        resolve_model(args.model) or args.model,
        "--host",
        args.host,
        "--port",
        str(args.port),
        "--page-size",
        str(args.page_size),
        "--enable-hierarchical-cache",
        "--hicache-ratio",
        str(args.hicache_ratio),
        "--hicache-size",
        str(args.hicache_size),
        "--hicache-io-backend",
        args.hicache_io_backend,
        "--hicache-write-policy",
        args.hicache_write_policy,
        "--enable-cache-report",
        "--enable-metrics",
    ]
    if args.tp and args.tp > 1:
        cmd.extend(["--tp", str(args.tp)])
    if args.hicache_mem_layout:
        cmd.extend(["--hicache-mem-layout", args.hicache_mem_layout])
    if args.hicache_storage_backend:
        cmd.extend(["--hicache-storage-backend", args.hicache_storage_backend])
    if args.hicache_storage_prefetch_policy:
        cmd.extend(["--hicache-storage-prefetch-policy", args.hicache_storage_prefetch_policy])
    if args.hicache_storage_backend_extra_config:
        cmd.extend(["--hicache-storage-backend-extra-config", args.hicache_storage_backend_extra_config])
    for extra in args.server_extra_arg:
        cmd.append(extra)
    return cmd


def build_vllm_apc_command(args: argparse.Namespace) -> List[str]:
    cmd = [
        "vllm",
        "serve",
        resolve_model(args.model) or args.model,
        "--host",
        args.host,
        "--port",
        str(args.port),
        "--enable-prefix-caching",
    ]
    if getattr(args, "dtype", None):
        cmd.extend(["--dtype", str(args.dtype)])
    if getattr(args, "tp", 1) and args.tp > 1:
        cmd.extend(["--tensor-parallel-size", str(args.tp)])
    for extra in args.server_extra_arg:
        cmd.append(extra)
    return cmd


def build_vllm_no_cache_command(args: argparse.Namespace) -> List[str]:
    cmd = [
        "vllm",
        "serve",
        resolve_model(args.model) or args.model,
        "--host",
        args.host,
        "--port",
        str(args.port),
        "--no-enable-prefix-caching",
    ]
    if getattr(args, "dtype", None):
        cmd.extend(["--dtype", str(args.dtype)])
    if getattr(args, "tp", 1) and args.tp > 1:
        cmd.extend(["--tensor-parallel-size", str(args.tp)])
    for extra in args.server_extra_arg:
        cmd.append(extra)
    return cmd


def build_sglang_radix_attention_command(args: argparse.Namespace) -> List[str]:
    cmd = [
        args.python_executable,
        "-m",
        "sglang.launch_server",
        "--model-path",
        resolve_model(args.model) or args.model,
        "--host",
        args.host,
        "--port",
        str(args.port),
        "--enable-cache-report",
        "--enable-metrics",
    ]
    if args.tp and args.tp > 1:
        cmd.extend(["--tp", str(args.tp)])
    if getattr(args, "attention_backend", None):
        cmd.extend(["--attention-backend", str(args.attention_backend)])
    for extra in args.server_extra_arg:
        if extra == "--disable-radix-cache":
            raise ValueError("SGLang RadixAttention baseline must not pass --disable-radix-cache")
        cmd.append(extra)
    return cmd


def build_lmcache_command(args: argparse.Namespace) -> tuple[List[str], Dict[str, str]]:
    env_updates: Dict[str, str] = {}
    if args.lmcache_chunk_size:
        env_updates["LMCACHE_CHUNK_SIZE"] = str(args.lmcache_chunk_size)
    if args.lmcache_config_file:
        env_updates["LMCACHE_CONFIG_FILE"] = args.lmcache_config_file

    model_name = resolve_model(args.model) or args.model
    if args.engine == "vllm":
        env_updates.update(vllm_compat_env_updates())
        cmd = [
            "vllm",
            "serve",
            model_name,
            "--host",
            args.host,
            "--port",
            str(args.port),
            "--enable-cache-report",
        ]
        if args.lmcache_mode == "transfer":
            cmd.extend(
                [
                    "--kv-transfer-config",
                    '{"kv_connector":"LMCacheConnectorV1","kv_role":"kv_both"}',
                ]
            )
        else:
            cmd.extend(
                [
                    "--kv-offloading-backend",
                    "lmcache",
                    "--kv-offloading-size",
                    str(args.kv_offloading_size),
                    "--disable-hybrid-kv-cache-manager",
                ]
            )
        for extra in args.server_extra_arg:
            cmd.append(extra)
        return cmd, env_updates

    cmd = [
        args.python_executable,
        "-m",
        "sglang.launch_server",
        "--model-path",
        model_name,
        "--host",
        args.host,
        "--port",
        str(args.port),
        "--enable-lmcache",
        "--enable-cache-report",
    ]
    if args.tp and args.tp > 1:
        cmd.extend(["--tp", str(args.tp)])
    if not args.lmcache_config_file:
        env_updates.setdefault("LMCACHE_LOCAL_CPU", "true")
        env_updates.setdefault("LMCACHE_USE_LAYERWISE", "true")
    for extra in args.server_extra_arg:
        cmd.append(extra)
    return cmd, env_updates


class ExternalAdmissionController:
    """Conservative ShadowKV++ admission wrapper for external runtimes.

    External runtimes own their KV cache internals. To keep this literature
    adapter honest, controller-denied requests are enforced by resetting the
    runtime prefix/radix cache before the request. This is conservative and may
    understate performance versus a hypothetical native per-request admission
    hook, but it avoids reporting simulated admission as a runtime result.
    """

    def __init__(self, model: str, runtime: str, min_match_length: int = 8) -> None:
        from proactive_kv_cache.cache import TieredStateBank

        self.runtime = runtime
        self.bank = TieredStateBank(max_memory_bytes=1024 * 1024, min_match_length=min_match_length)
        self.controller = AdaptiveReuseController()
        self.full_ms_per_token = 0.35
        self.reuse_overhead_ms = 1.0
        self._calibration_alpha = 0.20
        self._tokenizer = None
        self._token_to_id: Dict[str, int] = {}
        try:
            from transformers import AutoTokenizer

            self._tokenizer = AutoTokenizer.from_pretrained(model)
        except Exception:
            self._tokenizer = None

    def tokenize(self, text: str) -> tuple[int, ...]:
        if self._tokenizer is not None:
            return tuple(int(x) for x in self._tokenizer(text, truncation=True)["input_ids"])
        ids: List[int] = []
        for token in text.strip().split():
            if token not in self._token_to_id:
                self._token_to_id[token] = len(self._token_to_id) + 1
            ids.append(self._token_to_id[token])
        return tuple(ids)

    def _shared_prefix_hint(self, tokens: tuple[int, ...], metadata: Dict[str, Any] | None) -> int | None:
        if not metadata:
            return None
        hint = metadata.get("shared_prefix_hint_tokens")
        if hint is None:
            return None
        try:
            return min(int(hint), len(tokens))
        except Exception:
            return None

    def plan(self, prompt: str, metadata: Dict[str, Any] | None = None) -> tuple[ReusePlan, tuple[int, ...]]:
        tokens = self.tokenize(prompt)
        hint = self._shared_prefix_hint(tokens, metadata)
        tracked = [hint] if hint and hint >= self.bank.min_match_length else self.bank.default_prefix_lengths(tokens)
        self.bank.observe_query(tokens, tracked_prefix_lengths=tracked, reusable_prefix_limit=hint)
        match = self.bank.peek_match(tokens)
        exact_len = int(match[2]) if match is not None else 0
        sample = max(min(len(tokens), 32), 1)
        plan = self.controller.plan(
            tokens=tokens,
            exact_match_len=exact_len,
            semantic_similarity=0.0,
            semantic_prefix_len=0,
            shared_prefix_hint=hint,
            full_ms_per_token=self.full_ms_per_token,
            reuse_overhead_ms=self.reuse_overhead_ms,
            metadata=metadata,
        )
        return plan, tokens

    def _update_runtime_calibration(self, result: ExternalCallResult, tokens: tuple[int, ...]) -> None:
        prompt_tokens = int(result.prompt_tokens or len(tokens) or 0)
        if prompt_tokens <= 0 or result.latency_ms <= 0:
            return
        alpha = self._calibration_alpha
        cached_tokens = max(int(result.cached_tokens or 0), 0)
        if cached_tokens <= 0:
            observed = result.latency_ms / max(prompt_tokens, 1)
            self.full_ms_per_token = (1.0 - alpha) * self.full_ms_per_token + alpha * max(observed, 1e-6)
            return
        uncached = max(prompt_tokens - cached_tokens, 1)
        estimated_uncached_ms = uncached * max(self.full_ms_per_token, 1e-6)
        observed_overhead = max(result.latency_ms - estimated_uncached_ms, 0.0)
        self.reuse_overhead_ms = (1.0 - alpha) * self.reuse_overhead_ms + alpha * observed_overhead

    def should_store_after_bypass(self, tokens: tuple[int, ...], plan: ReusePlan, metadata: Dict[str, Any] | None = None) -> bool:
        hint = self._shared_prefix_hint(tokens, metadata)
        if hint is None or hint < self.bank.min_match_length:
            return False
        prefix = tokens[:hint]
        if self.bank.contains(prefix):
            return False
        suffix_len = max(len(tokens) - hint, 0)
        estimated_benefit = hint * max(self.full_ms_per_token, 1e-6)
        estimated_cost = self.reuse_overhead_ms + 0.02 * suffix_len
        future_utility = estimated_benefit - estimated_cost
        return future_utility >= 0.0 or float(plan.score) >= 0.0

    def record_after_request(
        self,
        tokens: tuple[int, ...],
        plan: ReusePlan,
        metadata: Dict[str, Any] | None = None,
        *,
        result: ExternalCallResult | None = None,
        allow_bypass_store: bool = False,
    ) -> bool:
        if result is not None:
            self._update_runtime_calibration(result, tokens)
        if plan.strategy == "bypass":
            self.controller.update_feedback(hit=False, wasted_ratio=0.0)
            if not allow_bypass_store or not self.should_store_after_bypass(tokens, plan, metadata=metadata):
                return False
            hint = self._shared_prefix_hint(tokens, metadata)
            if hint is None:
                return False
            prefix = tokens[:hint]
            return self.bank.store(prefix, None, prefill_cost_ms=0.0, memory_bytes=1, is_speculative=False, tier="external")
        hint = self._shared_prefix_hint(tokens, metadata)
        prefix_len = hint if hint and hint >= self.bank.min_match_length else min(len(tokens), max(self.bank.min_match_length, min(64, len(tokens))))
        prefix = tokens[:prefix_len]
        stored = self.bank.store(prefix, None, prefill_cost_ms=0.0, memory_bytes=1, is_speculative=False, tier="external")
        self.controller.update_feedback(hit=bool(result and result.cached_tokens > 0) or plan.strategy == "exact", wasted_ratio=0.0)
        return stored


def make_sglang_native_admission_extra_key(
    *,
    skip_lookup: bool,
    skip_write: bool,
    original_extra_key: str | None = None,
    tag: str | None = None,
) -> str:
    """Encode per-request SGLang cache-admission controls in extra_key.

    The patched SGLang runtime strips this control payload back out before
    cache namespacing, so allowed requests still share the normal Radix tree.
    """

    parts = [
        f"lookup={'0' if skip_lookup else '1'}",
        f"write={'0' if skip_write else '1'}",
    ]
    if tag:
        parts.append(f"tag={str(tag).replace(';', '_')}")
    if original_extra_key:
        parts.append(f"key={str(original_extra_key).replace(';', '_')}")
    return "__shadowkv_admission__:" + ";".join(parts)


def reset_runtime_cache(client: OpenAICompatClient, runtime: str, reset_external: bool = False) -> bool:
    candidates = []
    if runtime == "sglang":
        candidates.append("/flush_cache?timeout=30")
    else:
        suffix = "?reset_external=true" if reset_external else ""
        candidates.append(f"/reset_prefix_cache{suffix}")
    for path in candidates:
        try:
            client.post_empty(path, timeout_s=30.0)
            return True
        except Exception:
            continue
    return False


def load_trace_requests(trace_path: str) -> List[Request]:
    path = Path(trace_path)
    text = path.read_text(encoding="utf-8")
    rows: List[Dict[str, Any]] = []
    if path.suffix.lower() == ".jsonl":
        for line in text.splitlines():
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    else:
        data = json.loads(text)
        if isinstance(data, dict):
            rows = list(data.get("requests") or [])
        elif isinstance(data, list):
            rows = data
        else:
            raise ValueError(f"Unsupported trace format in {trace_path}")

    requests: List[Request] = []
    current_arrival = 0.0
    for idx, row in enumerate(rows):
        prompt = row.get("prompt")
        if prompt is None and row.get("messages"):
            prompt = "\n".join(str(msg.get("content", "")) for msg in row["messages"])
        if prompt is None:
            raise ValueError(f"Trace row {idx} is missing both prompt and messages")
        arrival = float(row.get("arrival_time", current_arrival))
        metadata = dict(row)
        nested_metadata = metadata.pop("metadata", None)
        if isinstance(nested_metadata, dict):
            metadata.update(nested_metadata)
        requests.append(Request(request_id=int(row.get("request_id", idx)), prompt=str(prompt), arrival_time=arrival, metadata=metadata))
        current_arrival = arrival
    return requests
